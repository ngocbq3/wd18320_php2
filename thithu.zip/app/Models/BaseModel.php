<?php

$conn = null;

$primaryKey = 'id';
function __construct()
{
    global $conn;
    $host = HOSTNAME;
    $dbname = DBNAME;
    $username = USERNAME;
    $password = PASSWORD;

    try {
        $conn = new PDO("mysql:host=$host; dbname=$dbname; charset=utf8", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (\PDOException $e) {
        echo "Lỗi kết nối dữ liệu: " . $e->getMessage();
    }
}

function all()
{
    global $conn, $tableName;
    $sqlBuilder = "SELECT * FROM $tableName";
    $stmt  = $conn->prepare($sqlBuilder);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_CLASS);
}

function find($id)
{
    global $conn, $tableName, $primaryKey;
    $sqlBuilder = "SELECT * FROM $tableName WHERE $primaryKey=:$primaryKey";
    $stmt  = $conn->prepare($sqlBuilder);
    $data = ["$primaryKey" => $id];
    $stmt->execute($data);
    $result = $stmt->fetchAll(PDO::FETCH_CLASS);
    //Trong trường hợp có dữ liệu
    if ($result) {
        return $result[0];
    }
    return $result;
}

function insert($data)
{
    global $conn, $tableName;
    $sqlBuilder = "INSERT INTO $tableName( ";

    //Biến values để nối các tham số cho value
    $values = "";
    foreach ($data as $column => $value) {
        $sqlBuilder .= "`{$column}`, ";
        $values .= ":$column, ";
    }
    //thực loại bỏ dấu ", " ở bên phải chuỗi bằng hàm rtrim
    $sqlBuilder = rtrim($sqlBuilder, ", ") . ") ";
    $values = "VALUES( " . rtrim($values, ", ") . ")";
    //Nối chuỗi sqlbuilder với values
    $sqlBuilder .= $values;

    $stmt = $conn->prepare($sqlBuilder);
    $stmt->execute($data);
    //trả lại giá trị id mới nhất
    return $conn->lastInsertId();
}

function update($id, $data)
{
    global $conn, $tableName, $primaryKey;
    $sqlBuilder = "UPDATE $tableName SET ";
    foreach ($data as $column => $value) {
        $sqlBuilder .= "`{$column}`=:$column, ";
    }
    //Xóa dấu ", " ở cuối chuỗi
    $sqlBuilder = rtrim($sqlBuilder, ", ");
    //Thêm điều kiện cho câu lệnh SQL
    $sqlBuilder .= " WHERE `$primaryKey`=:$primaryKey";

    $stmt = $conn->prepare($sqlBuilder);
    //Thêm $id vào $data
    $data["$primaryKey"] = $id;
    return $stmt->execute($data);
}

/**
 * method delete: để xóa dữ liệu theo id
 */
function delete($id)
{
    global $conn, $tableName, $primaryKey;
    $sqlBuilder = "DELETE FROM $tableName WHERE `$primaryKey`=:$primaryKey";
    $stmt = $conn->prepare($sqlBuilder);
    return $stmt->execute(["$primaryKey" => $id]);
}
