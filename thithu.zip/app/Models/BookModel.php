<?php

$tableName = "sach";
require_once "BaseModel.php";
