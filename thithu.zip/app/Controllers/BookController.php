<?php
require_once "app/Models/BookModel.php";
require_once "BaseController.php";
function index()
{
    __construct();
    $books = all();
    return view(
        "list",
        ["books" => $books]
    );
}
