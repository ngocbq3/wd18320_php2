<?php

require_once __DIR__ . "/env.php";
require_once __DIR__ . "/config.php";

require_once __DIR__ . "/app/Controllers/BookController.php";

index();
