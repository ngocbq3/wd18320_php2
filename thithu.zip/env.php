<?php

//Thông tin của database
const HOSTNAME = "localhost";
const DBNAME = "books";
const USERNAME = "root";
const PASSWORD = "";
